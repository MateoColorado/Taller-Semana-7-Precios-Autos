/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package calculavalorliquidacion;

/**
 *
 * @author SANTIAGO CUERVO
 */
public class CalculadoraPrograma extends objetoVehiculo{
    //Atributos e la clase
    private double descuentoPP = 0.2;
    private double descuentoSP = 150;
    private double descuentoTC = 0.3;
    private double procesoPP = 0.0;
    private double procesoSP = 0.0;
    private double procesoTC = 0.0;

    public CalculadoraPrograma(String marcaVehiculo, String lineaVehiculo, int añoVehiculo, boolean DescPP, boolean DescSP, boolean DescTC) {
        super(marcaVehiculo, lineaVehiculo, añoVehiculo, DescPP, DescSP, DescTC);
        this.descuentoPP = descuentoPP;
        this.descuentoSP = descuentoSP;
        this.descuentoTC = descuentoTC;
        this.procesoPP = procesoPP;
        this.procesoSP = procesoSP;
        this.procesoTC = procesoTC;
    }

    public CalculadoraPrograma() {
    }

    public double getDescuentoPP() {
        return descuentoPP;
    }

    public void setDescuentoPP(double descuentoPP) {
        this.descuentoPP = descuentoPP;
    }

    public double getDescuentoSP() {
        return descuentoSP;
    }

    public void setDescuentoSP(double descuentoSP) {
        this.descuentoSP = descuentoSP;
    }

    public double getDescuentoTC() {
        return descuentoTC;
    }

    public void setDescuentoTC(double descuentoTC) {
        this.descuentoTC = descuentoTC;
    }

    public double getProcesoPP() {
        return procesoPP;
    }

    public void setProcesoPP(double procesoPP) {
        this.procesoPP = procesoPP;
    }

    public double getProcesoSP() {
        return procesoSP;
    }

    public void setProcesoSP(double procesoSP) {
        this.procesoSP = procesoSP;
    }

    public double getProcesoTC() {
        return procesoTC;
    }

    public void setProcesoTC(double procesoTC) {
        this.procesoTC = procesoTC;
    }
    
    

    



    //funciones con descuento:
    
    public double DescuentoPP(int valorV, boolean DescPP)
    {
        double descuentoTotPP = 0.0;
        if(DescPP == true)
        {
            procesoPP = valorV * descuentoPP;
        }
        
        descuentoTotPP = valorV - procesoPP;
        return(descuentoTotPP);
    }   
    
    public double DescuentoSP(boolean DescSP, double descuentoTotPP, int valorV)
    {
        double descuentoTotSP = 0.0;
        if(descuentoTotPP == 0.0)
        {
            descuentoTotPP = valorV; 
        }
        if(DescSP == true)
        {
            procesoSP = descuentoSP;
        }
         descuentoTotSP = descuentoTotPP - procesoSP;
        return(descuentoTotSP);
    }
    
    
    public double DescuentoTC(double descuentoTotSP,boolean DescTC, int valorV)
    {
        double descuentoTotTC = 0.0;
        if(descuentoTotSP == 0.0)
        {
            descuentoTotSP = valorV;
        }
        if(DescTC == true)
        {
            procesoTC = descuentoTotSP * descuentoTC;
        }
        descuentoTotTC = descuentoTotSP - procesoTC;
        return(descuentoTotTC);
    }
    
    
    
    
    
}
