/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package calculavalorliquidacion;

import javax.swing.JOptionPane;

/**
 *
 * @author SANTIAGO CUERVO
 */
public class objetoVehiculo {
    
    //encapsulamiento
    private String marcaVehiculo;
    private String lineaVehiculo;
    private int añoVehiculo;
    private boolean DescPP;
    private boolean DescSP;
    private boolean DescTC;
    private int valorR = 7500;//7500
    private int valorC = 6800;//6800

    public objetoVehiculo(String marcaVehiculo, String lineaVehiculo, int añoVehiculo, boolean DescPP, boolean DescSP, boolean DescTC) {
        this.marcaVehiculo = marcaVehiculo;
        this.lineaVehiculo = lineaVehiculo;
        this.añoVehiculo = añoVehiculo;
        this.DescPP = DescPP;
        this.DescSP = DescSP;
        this.DescTC = DescTC;
        this.valorC = valorC;
        this.valorR = valorR;
    }
    

    public objetoVehiculo(){
        
    }
    
    
    
    public boolean isDescPP() {
        return DescPP;
    }

    public void setDescPP(boolean DescPP) {
        this.DescPP = DescPP;
    }

    public boolean isDescSP() {
        return DescSP;
    }

    public void setDescSP(boolean DescSP) {
        this.DescSP = DescSP;
    }

    public boolean isDescTC() {
        return DescTC;
    }

    public void setDescTC(boolean DescTC) {
        this.DescTC = DescTC;
    }

    public String getMarcaVehiculo() {
        return marcaVehiculo;
    }

    public void setMarcaVehiculo(String marcaVehiculo) {
        this.marcaVehiculo = marcaVehiculo;
    }

    public String getLineaVehiculo() {
        return lineaVehiculo;
    }

    public void setLineaVehiculo(String lineaVehiculo) {
        this.lineaVehiculo = lineaVehiculo;
    }

    public int getAñoVehiculo() {
        return añoVehiculo;
    }

    public void setAñoVehiculo(int añoVehiculo) {
        this.añoVehiculo = añoVehiculo;
    }
    
    public int getvalorC() {
        return valorC;
    }

    public void setvalorC(int valorC) {
        this.valorC = valorC;
    }
    
    public int getvalorR() {
        return valorR;
    }

    public void setvalorR(int valorR) {
        this.valorR = valorR;
    }
    
//Validar precios vehiculos
    
    public int valorVehiculo(String marcaV, String lineaV, int año){
        boolean cond1,cond2;
        int valorV = 0;
        cond1 = (marcaV == "Renault" && lineaV == "Duster" && año == 2012);
        cond2 = (marcaV == "Chevrolet" && lineaV == "Spark" && año == 2010);
        
        if(cond1 == true)
        {
            JOptionPane.showMessageDialog(null, "Vehículo Renault Aceptado...");
            valorV = valorR;
        }
        if(cond2 == true)
        {
            JOptionPane.showMessageDialog(null, "Vehículo Chevrolet Aceptado...");
            valorV = valorC;            
        }
        if(cond1 == false && cond2 == false)
        {
            JOptionPane.showMessageDialog(null, "Error de Busqueda...no existe dicho vehículo");
        }
        
        return (valorV);
    }
    
    
    
    
}
